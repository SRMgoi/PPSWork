# Reverse a string in Python
def reverse_string(s):
    return s[::-1]

# Example usage
text = input("Enter a string: ")
print("Reversed string:", reverse_string(text))
