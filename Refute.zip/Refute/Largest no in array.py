# Find largest number in Python
def find_largest(arr):
    largest = arr[0]
    for num in arr:
        if num > largest:
            largest = num
    return largest

# Example usage
arr = [10, 20, 5, 40, 25]
print("Array:", arr)
print("Largest number:", find_largest(arr))
